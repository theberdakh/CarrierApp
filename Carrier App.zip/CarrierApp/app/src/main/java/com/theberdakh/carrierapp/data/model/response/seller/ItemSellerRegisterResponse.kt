package com.theberdakh.carrierapp.data.model.response.seller

data class ItemSellerRegisterResponse(
    val karer_name: String,
    val phone_number: String
)