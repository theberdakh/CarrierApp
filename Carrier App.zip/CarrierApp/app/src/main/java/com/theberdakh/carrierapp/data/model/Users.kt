package com.theberdakh.carrierapp.data.model


data class User(
    val phoneNumber: String,
    val password: String
)
data class Seller(
    val name: String
)

data class TaxManager(
    val name: String
)

data class Carrier(
    val name: String
)