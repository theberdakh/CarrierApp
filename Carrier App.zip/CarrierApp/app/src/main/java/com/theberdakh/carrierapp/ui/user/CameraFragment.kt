package com.theberdakh.carrierapp.ui.user

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import android.view.TextureView
import android.view.View
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.theberdakh.carrierapp.R
import com.theberdakh.carrierapp.data.local.Constants
import com.theberdakh.carrierapp.databinding.FragmentCameraBinding
import com.theberdakh.carrierapp.util.makeToast

class CameraFragment : Fragment(R.layout.fragment_camera) {
    private lateinit var binding: FragmentCameraBinding
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding = FragmentCameraBinding.bind(view)

        binding.textureView.addCameraOpenedListener {

        }.addCameraErrorListener { t, errorLevel ->

        }.addCameraClosedListener {

        }


        }

    override fun onResume() {
        super.onResume()
        if (ActivityCompat.checkSelfPermission(
                requireActivity().baseContext,
                Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        binding.textureView.start()
    }

    override fun onPause() {
        binding.textureView.stop()
        super.onPause()
    }

    override fun onDestroyView() {
        binding.textureView.destroy()
        super.onDestroyView()
    }
}



   /* private fun initViews() {
        if (allPermissionsGranted()) {
            makeToast("Kameradan paydalanıw ushın ruxsat berildi.")
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                requireActivity(),
                Constants.REQUIRED_PERMISSIONS,
                Constants.REQUEST_CODE_PERMISSIONS
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        if (requestCode == Constants.REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                makeToast("Kameradan paydalanıw ushın ruxsat berilmegen")
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startCamera() {
        val cameraManager = requireActivity().getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val handlerThread = HandlerThread("photoThread")
        handlerThread.start()
        val  handler = Handler((handlerThread).looper)



        cameraManager.openCamera(
            cameraManager.cameraIdList[0],
            object : CameraDevice.StateCallback() {

                override fun onOpened(camera: CameraDevice) {
                    val capReq = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                    val surface = Surface(binding.textureView.surfaceTexture)
                    capReq.addTarget(surface)

                    camera.createCaptureSession(listOf(surface), object :
                        CameraCaptureSession.StateCallback() {
                        override fun onConfigured(session: CameraCaptureSession) {
                            session.setRepeatingRequest(capReq.build(), null, null)
                        }

                        override fun onConfigureFailed(session: CameraCaptureSession) {

                        }

                    }, handler)
                }

                override fun onDisconnected(camera: CameraDevice) {

                }

                override fun onError(camera: CameraDevice, error: Int) {
                }

            },
            handler
        )


        *//* val cameraProviderFuture = ProcessCameraProvider.getInstance(requireActivity())

         cameraProviderFuture.addListener({
             val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()





             val preview = Preview.Builder()
                 .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                 .build()
                 .also { mPreview ->
                     mPreview.setSurfaceProvider(binding.textureView.surfaceProvider)
                 }


             imageCapture = ImageCapture.Builder()
                 .build()



             val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
             try {
                 cameraProvider.unbindAll()
                 cameraProvider.bindToLifecycle(
                     requireActivity(),
                     cameraSelector,
                     preview,
                     imageCapture
                 )

             } catch (e: Exception){
                 Log.d(Constants.TAG, "startCamera Fail: ", e)
             }
         }, ContextCompat.getMainExecutor(requireActivity()))*//*


    }


    private fun allPermissionsGranted() =
        Constants.REQUIRED_PERMISSIONS.all {
            ContextCompat.checkSelfPermission(
                requireActivity().baseContext,
                it
            ) == PackageManager.PERMISSION_GRANTED
        }*/

