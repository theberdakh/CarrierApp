package com.theberdakh.carrierapp.data.model.response.seller

data class SellerResponse(
    val token: String,
    val itemSellerRegisterResponse: ItemSellerRegisterResponse
)