package com.theberdakh.carrierapp.data.model.response.login

import javax.annotation.processing.Generated

data class LoginBody(
    val phone_number: String,
    val password: String
)